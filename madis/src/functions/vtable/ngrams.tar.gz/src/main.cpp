#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <iostream>
#include <unistd.h>
#include <algorithm>
#include <unordered_map>
#include <unordered_set>
#include <string.h>
#include <queue>
#include <pthread.h>
#include <set>

#include "threadpool11/threadpool11.hpp"

#define NUM_OF_THREADS 4


using namespace std;
using namespace __gnu_cxx;


typedef struct Ngram {
    vector<string> text_;
    vector<unsigned int> ints_;
    unsigned int ngram_id_;
    unsigned int best_word_;
    unsigned int size_;
    unsigned int version_;
    bool deleted_;
    unsigned int del_version_;
    Ngram(){
        best_word_ = 0;
        deleted_ = false;
    }
} Ngram;

typedef struct Index {
    unordered_map<int, vector<Ngram>> index_;
    unordered_map<string, int> word_to_int_;
    unordered_map<string, int> word_frequency_;
    unordered_map<string, int> ngrams_;
    unsigned int word_int_;
    unsigned int ngram_id_;
    Index(){
        word_int_ = 0;
        ngram_id_ = 0;
    }


} Index;

typedef struct Job {
    Index &index;
    vector<string> text;
    int result_id;
    int version;
    Job(Index &i, vector<string> &t, int res, int v) : index(i), text(std::move(t)), result_id(res), version(v) {}

} Job;

vector<vector<std::pair<int, Ngram>>> results;

void split( std::string const& original, char separator , std::vector<std::string> &results)
{
    std::string::const_iterator start = original.begin() + 1;
    std::string::const_iterator end = original.end();
    std::string::const_iterator next = std::find( start, end, separator );
    while ( next != end ) {
        std::string temp = std::string(start, next);
        if(!temp.empty()){
            //results.push_back( std::string( start, next ) );
            results.push_back(temp);
        }
        start = next + 1;
        next = std::find( start, end, separator );
    }
    std::string temp = std::string(start, next);
    if(!temp.empty())
        //results.push_back( std::string( start, next ) );
        results.push_back(temp);
}

std::vector<std::string> split( std::string const& original, char separator )
{
    std::vector<std::string> results;
    split(original, separator, results);
    return results;
}

bool result_sort(const std::pair<int, Ngram>& n1, const std::pair<int, Ngram>& n2){
    if (n1.first == n2.first){
        return n1.second.size_ < n2.second.size_;
    }
    return n1.first < n2.first;
}

//void index_add(Index &index, vector<std::pair<vector<string>, int>> &add){
void index_add(Index &index, vector<std::pair<string, int>> &add){
    vector<Ngram> ngrams;

    for(vector<std::pair<string, int>>::iterator it = add.begin(); it != add.end(); it++){
        Ngram ngram;
        ngram.version_ = it->second;
        ngram.ngram_id_ = index.ngram_id_;
        index.ngram_id_++;

        vector<string> vline = split(it->first, ' ');
        ngram.text_ = vline;
        ngram.size_ = vline.size();
        for(vector<string>::iterator itt = vline.begin(); itt != vline.end(); itt++){
            index.word_frequency_[*itt] += 1;
            if(index.word_to_int_.find(*itt) == index.word_to_int_.end()){
                index.word_to_int_[*itt] = index.word_int_;
                index.word_int_++;
            }
            ngram.ints_.push_back(index.word_to_int_[*itt]);
        }
        ngrams.push_back(ngram);
    }
    vector<std::pair<string, int>>::iterator it_line = add.begin();
    for(vector<Ngram>::iterator it = ngrams.begin(); it != ngrams.end(); it++){
        int best = index.word_frequency_[*it->text_.begin()];
        int counter = 0;
        for(vector<string>::iterator itt = it->text_.begin() + 1; itt != it->text_.end(); itt++){
            counter++;
            if(index.word_frequency_[*itt] < best){
                best = index.word_frequency_[*itt];
                it->best_word_ = counter;
            }
        }
        index.index_[it->ints_[it->best_word_]].push_back(*it);
        index.ngrams_[it_line->first] = it->ints_[it->best_word_];
        it_line++;
    }
}

void index_del(Index &index, vector<std::pair<string, int>> &del, vector<std::pair<int, int>> &real_del){
    for(vector<std::pair<string, int>>::iterator it = del.begin(); it != del.end(); it++){
        int word = index.ngrams_[it->first];
        vector<Ngram> &ngrams = index.index_.find(word)->second;
        vector<string> vline = split(it->first, ' ');
        int pos = 0;
        for(vector<Ngram>::iterator itt = ngrams.begin(); itt != ngrams.end(); itt++){
            if(vline.size() == itt->size_ && std::equal(vline.begin(), vline.end(), itt->text_.begin())){
                itt->deleted_ = true;
                itt->del_version_ = it->second;
                real_del.push_back(make_pair(word, pos));
                break;
            }
            pos++;
        }
    }
}

void index_search(const Index &index, const vector<string> &text, const int query, const int version){
    //cout << "running for " << query << endl; 
    //
    //cout << "index size: " << index.index_.size() << endl;
    //cout << "text size: " << text.size() << endl;
    //cout << "query: " << query << endl;

    vector<int> int_text;
    vector<int> non_words;
    int text_position = 1;
    for(vector<string>::const_iterator st = text.begin(); st != text.end(); st++){
        unordered_map<string, int>::const_iterator word_it = index.word_to_int_.find(*st);
        if(word_it != index.word_to_int_.end()){
            int_text.push_back(word_it->second);
        }
        else{
            int_text.push_back(-1);
            non_words.push_back(text_position);
        }
        text_position++;
    }
    non_words.push_back(text_position);

    unordered_set<int> current_ngrams;
    vector<int>::const_iterator nword = non_words.begin();
    int back = 0;
    int front = *nword;
    int position = 0;
    for(vector<int>::const_iterator it = int_text.begin(); it != int_text.end(); ++it){
        position++;

        if(*it == -1){
            back = front;
            nword++;
            front = *nword;
            continue;
        }

        //const vector<Ngram> &ng = index_[*it];
        unordered_map<int, vector<Ngram>>::const_iterator ng = index.index_.find(*it);

        if(ng != index.index_.end()){
            //for(vector<Ngram>::const_iterator ng_it = ng.begin(); ng_it != ng.end(); ++ng_it){
            for(vector<Ngram>::const_iterator ng_it = ng->second.begin(); ng_it != ng->second.end(); ++ng_it){
                /*
                if(ng_it->text_[ng_it->best_word_] == "cause"){
                    cout << "version: " << version << endl;
                    cout << "cause: " << ng_it->version_ << endl;
                    cout << "cause: " << ng_it->del_version_ << endl;
                    cout << "cause: " << ng_it->deleted_ << endl;
                }
                */
                if(ng_it->version_ > version || (ng_it->deleted_ && version > ng_it->del_version_)){
                    continue;
                }
                int best_pos = ng_it->best_word_;
                int last_pos = ng_it->size_;
                //cout << *it << endl;
                //cout << "front: " << front << " back: " << back << " best_pos: " << best_pos << " last_pos: " << last_pos << endl;
                //if(position+last_pos-best_pos-1 >= front || position-best_pos <= back){
                if(position-best_pos <= back || position+last_pos-best_pos-1 >= front){
                    /*
                    if(front - back - 1 < last_pos){
                        break;
                    }
                    */
                    continue;
                }
                vector<int>::const_iterator itt = it;
                        
                int pos = best_pos; 
                bool nope = false;

                //while(pos > 0 && itt != file.begin()){
                while(pos > 0){
                    pos--;
                    itt--;
                    
                    if(ng_it->ints_[pos] != *itt){
                        nope = true;
                        break;
                    }
                }
                if(nope || pos != 0){
                    continue;
                }

                itt = it;
                pos = best_pos;
                pos++;
                itt++;
                //while(pos < last_pos && itt != file.end()){
                while(pos < last_pos){
                    if(ng_it->ints_[pos] != *itt){
                        nope = true;
                        break;
                    }
                    pos++;
                    itt++;
                }
                int id = ng_it->ngram_id_;
                //if(!nope && pos == last_pos){
                if(!nope && pos == last_pos && current_ngrams.find(id) == current_ngrams.end()){
                    results[query].push_back(std::make_pair(position-best_pos,*ng_it));
                    current_ngrams.insert(id);
                }
            }
        }
    }
    sort(results[query].begin(), results[query].end(), result_sort);
}

threadpool11::Pool query_pool;
int threadCounter = 0;
unordered_map <pthread_t, int> threadIds;
mutex mtx;

void initThread(){
	mtx.lock();
	unordered_map<pthread_t, int>::const_iterator um_it = threadIds.find(pthread_self());
	//cerr << "Thread id " <<  pthread_self() << " -> "<< threadCounter << endl;
	threadIds.emplace(pthread_self(), threadCounter);

	 /*cpu_set_t cpuset;
	 CPU_ZERO(&cpuset);
	 CPU_SET(threadCounter, &cpuset);

	 int rc = pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset);
	 if (rc != 0)
		 std::cerr << "Error calling pthread_setaffinity_np: " << rc << "\n";*/


	threadCounter++;
	mtx.unlock();

	sleep(1);
}

int main() {
    Index index;

    string line;
    char c;
    vector<std::pair<string, int>> add;
    vector<std::pair<string, int>> del;
    vector<std::pair<int, int>> real_del;


    vector<Job> thread_queue;
    thread_queue.reserve(20000);

    while(cin >> c){
        if(c == 'A'){
            getline(cin, line);
            //vector<string> vline = split(line, ' ');
            add.push_back(make_pair(line,0));
        }
        if(c == 'S'){
            index_add(index, add);
            break;
        }
    }
    add.clear();

    int queries = 0;
    query_pool.setWorkerCount(NUM_OF_THREADS);
    for(int i = 0; i < NUM_OF_THREADS; i++){
        query_pool.postWork<void>(initThread);
    }
    query_pool.waitAll();

    //preprocess
    cout << "R" << endl;
    //
    int version = 1;

    while(cin >> c){
        if(c == 'F'){
            results.resize(queries);
            //make_additions
            index_add(index, add);
            //make_deletions
            index_del(index, del, real_del);
            for(vector<Job>::iterator it = thread_queue.begin(); it != thread_queue.end(); it++){
                query_pool.postWork<void>([it] { index_search(it->index, it->text, it->result_id, it->version); });
            }
            add.clear();
            del.clear();
            query_pool.waitAll();
            thread_queue.clear();
            for(int i = 0; i < queries; i++){
                for(vector<std::pair<int, Ngram>>::const_iterator it = results[i].begin(); it != results[i].end(); ++it){
                    vector<string>::const_iterator itt;
                    //cout << i << ":";
                    for(itt = it->second.text_.begin(); itt != it->second.text_.end() - 1; ++itt) {
                        cout << *itt << " ";
                    }
                    cout << *itt << "|";
                }
                cout << endl;
            }
            results.clear();
            queries = 0;

            //real_delete
            for(vector<pair<int, int>>::iterator it = real_del.begin(); it != real_del.end(); it++){
                vector<Ngram> &ngrams = index.index_[it->first];
                ngrams.erase(ngrams.begin() + it->second);
            }
            real_del.clear();
            continue;
        }

        getline(cin, line);
        if(c == 'A'){
            add.push_back(make_pair(line, version));
            version++;
        }
        else if(c == 'D'){
            del.push_back(make_pair(line, version));
            version++;
        }
        else if(c == 'Q'){
            //results.resize(queries+1);
            //index_search(index, vline, queries);
            vector<string> vline = split(line, ' ');
            Job job(index, vline, queries, version);
            thread_queue.push_back(job);
            version++;
            queries++;
        }
    }
    return 0;
}
